package facilityGame;

public enum EnumPlayer {
	PLAYER_A, PLAYER_B
}
