package facilityGame;

public enum EnumClientServer {
	CLIENT, SERVER
}
