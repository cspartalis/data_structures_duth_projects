package facilityGame;

public class FacilityGameException extends Exception {
	
	public FacilityGameException(String s) {
		super(s);
	}
}
