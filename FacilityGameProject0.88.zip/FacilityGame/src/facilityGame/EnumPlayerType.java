package facilityGame;

public enum EnumPlayerType {
	FPLAYER_SIMPLE_1, // Reserved, do not change
	FPLAYER_SIMPLE_2, // Reserved, do not change
	FPLAYER_SIMPLE_3, // Reserved, do not change
	FPLAYER_201112, // Reserved, do not change
	FPLAYER_201213A, // Reserved, do not change
	FPLAYER_201213B, // Reserved, do not change
	FPLAYER_201314, // Reserved, do not change
	FPLAYER_201415, // Reserved, do not change
	FPLAYER_201516A, // Reserved, do not change
	FPLAYER_201516B, // Reserved, do not change
	FPLAYER_201617, // Reserved, do not change
	FPLAYER_COPY, // Reserved, do not change
	FPLAYER_COMPLEMENT, // Reserved, do not change
	FPLAYER_NOTRIPLES, // Reserved, do not change
	FPLAYER_TEST, // Reserved, do not change
	FPLAYER_SLOW, // Reserved, do not change 
	FPLAYER_GR, // Reserved, do not change 
	FPLAYER_MY_1, // ��� ��� ��� ���� �����������, ��������� ���.
	FPLAYER_MY_2
}
