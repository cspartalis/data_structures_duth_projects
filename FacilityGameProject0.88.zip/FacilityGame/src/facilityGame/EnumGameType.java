package facilityGame;

public enum EnumGameType {
	NORMAL, // normal facility game 
	COPY,	// facility game where player B has to imitate player A
	COMPLEMENT, // facility game where player B has to choose nodes of complementary value to player's B moves
	NOTRIPLES // facility game where player B has to prevent player A from allocating triples of nodes
}
