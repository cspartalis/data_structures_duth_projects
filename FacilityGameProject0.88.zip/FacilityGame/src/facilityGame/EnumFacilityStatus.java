package facilityGame;

public enum EnumFacilityStatus {
	FREE, BLOCKED, PLAYER_A, PLAYER_B;
}
