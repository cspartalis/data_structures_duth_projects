package facilityGame;

public enum EnumPlayerState {
	STARTING, WAITING_FOR_ME, WAITING_FOR_OPPONENT, TERMINATING
}
